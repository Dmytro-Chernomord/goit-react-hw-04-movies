import React from 'react';

const MovieList = () => {
  return <ul>{}</ul>;
};
