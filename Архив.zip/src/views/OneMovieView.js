import React, { Component } from 'react';
import fetch from '../components/Api/api';

export class OneMovieView extends Component {
  render() {
    return <div></div>;
  }
}

export default OneMovieView;
